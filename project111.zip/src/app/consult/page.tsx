import React from 'react';

const consult = () => {

    return (
        <div>
            <h1>회사소개페이지</h1>
        </div>
    );

};

export default consult;