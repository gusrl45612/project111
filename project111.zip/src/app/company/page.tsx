'use client';
import React from 'react';

const company = () => {

    return (
        <div>
            <h1>회사소개 페이지</h1>
        </div>
    );

};

export default company;