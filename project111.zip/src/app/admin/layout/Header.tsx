const AdminHeader = () => {

    return(
        <>
        <h1>제발 헤더좀 없어져!!!</h1>
        </>

    );
};

export default AdminHeader;