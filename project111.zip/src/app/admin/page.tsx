import React from "react";

const AdminPage = () => {
  return (
    <div>
      <h1>어드민 대시보드</h1>
    </div>
  );
};

export default AdminPage;