import { FC, Fragment, ReactElement } from 'react';
import Header from './Header';
import Footer from './Footer';



type LayoutProps = Required<{
  readonly children: ReactElement;
}>;

const DefaultLayout: FC<LayoutProps> = ({ children }) => {
  return (
    <Fragment>
      <Header />
      {children}
      <Footer/>
    </Fragment>
  );
};

export default DefaultLayout;