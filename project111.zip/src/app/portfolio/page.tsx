import React from 'react';

const portfolio = () => {
  return (
    <div>
      <h1>포트폴리오 페이지</h1>
    </div>
  );
};

export default portfolio;
