'use client';
import React from 'react';
import Content from './components/layout/Content';


const HomePage = () => {
  return (
    <>
      <Content />
    </>
  );
};

export default HomePage;